#!/usr/bin/env python3
"""Personal website + private cabinet. Python 3.10+, standard library only."""
import argparse
import datetime as dt
import hashlib
import hmac
import io
import ipaddress
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
import unicodedata
from urllib.parse import unquote, urlparse
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE = Path(__file__).resolve().parent
DATA = Path(os.environ.get('SITE_DATA_DIR', str(BASE / 'data'))).expanduser()
UPLOADS = DATA / 'uploads'
MEDIA = DATA / 'media'
DB = DATA / 'site.sqlite3'
STATIC = BASE / 'static'
for d in (DATA, UPLOADS, MEDIA): d.mkdir(parents=True, exist_ok=True)
FILE_LIMIT = 20 * 1024 * 1024
IMAGE_LIMIT = 5 * 1024 * 1024
SESSION_SECS = 14 * 86400
RATE = {}
RATE_LOCK = threading.Lock()
MAX_JSON = 512 * 1024
DEFAULT_PROFILE = {
    'name': 'Yuriy Project', 'role': 'Личный сайт и пространство', 'location': '',
    'bio': 'Добро пожаловать в моё пространство. Здесь я делюсь идеями, проектами и тем, что для меня важно.',
    'about': 'Это мой персональный сайт. В личном кабинете я могу обновлять информацию, вести заметки, управлять задачами и хранить файлы.',
    'email': '', 'telegram': '', 'website': '', 'avatar_file': '',
}


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def db_connect():
    c = sqlite3.connect(DB, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=15000')
    return c


def initialize():
    with db_connect() as db:
        db.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, password_salt TEXT NOT NULL, password_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, csrf TEXT NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS profile(id INTEGER PRIMARY KEY CHECK(id = 1), name TEXT NOT NULL, role TEXT NOT NULL, location TEXT NOT NULL,
            bio TEXT NOT NULL, about TEXT NOT NULL, email TEXT NOT NULL, telegram TEXT NOT NULL, website TEXT NOT NULL, avatar_file TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL,
            description TEXT NOT NULL, url TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, status TEXT NOT NULL,
            due_date TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL,
            updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT NOT NULL, stored TEXT NOT NULL UNIQUE,
            size INTEGER NOT NULL, mime TEXT NOT NULL, uploaded_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL,
            body TEXT NOT NULL, is_read INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
        ''')
        db.execute('INSERT OR IGNORE INTO profile(id,name,role,location,bio,about,email,telegram,website,avatar_file) VALUES(1,?,?,?,?,?,?,?,?,?)', tuple(DEFAULT_PROFILE.values()))
        db.execute('DELETE FROM sessions WHERE expires_at < ?', (int(time.time()),))
        # На публичном хостинге первоначального владельца создаём из секрета
        # провайдера. Публичная регистрация владельца всегда выключена.
        if os.environ.get('SITE_REMOTE_DEPLOY') == '1':
            owner_exists = db.execute('SELECT 1 FROM users WHERE id=1').fetchone()
            if not owner_exists:
                first_password = os.environ.get('SITE_ADMIN_PASSWORD', '')
                if len(first_password) < 12 or len(first_password) > 200:
                    raise RuntimeError('Для публикации задайте SITE_ADMIN_PASSWORD длиной от 12 до 200 символов в секретах хостинга.')
                salt, hashed = hash_password(first_password)
                db.execute('INSERT INTO users(id,password_salt,password_hash) VALUES(1,?,?)', (salt, hashed))


def hash_password(password, salt=None):
    if salt is None: salt = secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), 350000).hex()
    return salt, hashed


def is_local(addr):
    try: return ipaddress.ip_address(addr).is_loopback
    except ValueError: return False


def throttle(key, limit, window):
    t = time.monotonic()
    with RATE_LOCK:
        a = RATE.setdefault(key, [])
        a[:] = [x for x in a if t-x < window]
        if len(a) >= limit: return False
        a.append(t)
        if len(RATE) > 5000:
            for k in list(RATE)[:1000]:
                if not RATE[k] or t-RATE[k][-1] > 3600: RATE.pop(k, None)
    return True


def clean_text(value, max_chars, strip=True):
    if not isinstance(value, str): raise ValueError('Ожидался текст')
    value = value.strip() if strip else value
    if len(value) > max_chars: raise ValueError(f'Слишком длинный текст (максимум {max_chars} символов)')
    return value


def public_link(value):
    value = clean_text(value, 500)
    if value and urlparse(value).scheme not in ('https','http'): raise ValueError('Укажите ссылку, начинающуюся с https://')
    return value


def table_dicts(db, sql, params=()):
    return [dict(r) for r in db.execute(sql, params).fetchall()]


def profile_dict(db):
    return dict(db.execute('SELECT * FROM profile WHERE id=1').fetchone())


def get_session(db, cookie):
    match = re.search(r'(?:^|;\s*)session=([a-f0-9]{64})(?:;|$)', cookie)
    if not match: return None
    row = db.execute('SELECT * FROM sessions WHERE token_hash=? AND expires_at>?', (hashlib.sha256(match.group(1).encode()).hexdigest(), int(time.time()))).fetchone()
    return dict(row) if row else None


class App(BaseHTTPRequestHandler):
    server_version = 'PersonalSpace/1.0'
    sys_version = ''

    def log_message(self, fmt, *args):
        print('%s [%s] %s' % (self.client_address[0], self.log_date_time_string(), fmt % args), flush=True)

    def headers_base(self, content_type='application/json; charset=utf-8', length=None, extra=None, no_store=False):
        self.send_header('Content-Type', content_type)
        if length is not None: self.send_header('Content-Length', str(length))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'strict-origin-when-cross-origin')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'")
        if os.environ.get('SITE_REMOTE_DEPLOY') == '1':
            self.send_header('Strict-Transport-Security', 'max-age=31536000')
        if no_store: self.send_header('Cache-Control', 'no-store')
        if extra:
            for key,val in extra.items(): self.send_header(key,val)

    def respond(self, code, data, extra=None):
        payload = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.headers_base(length=len(payload), extra=extra, no_store=True)
        self.end_headers()
        self.wfile.write(payload)

    def fail(self, code, message):
        self.respond(code, {'error': message})

    def read_bytes(self, limit):
        try: size = int(self.headers.get('Content-Length', '-1'))
        except ValueError: raise ValueError('Некорректный размер запроса')
        if size < 0: raise ValueError('Не указан Content-Length')
        if size > limit: raise ValueError('Превышен допустимый размер файла или запроса')
        return self.rfile.read(size)

    def json_body(self):
        raw = self.read_bytes(MAX_JSON)
        try: data = json.loads(raw)
        except (ValueError, UnicodeError): raise ValueError('Некорректный JSON')
        if not isinstance(data, dict): raise ValueError('Ожидался объект JSON')
        return data

    def current_session(self, db, mutation=False):
        session = get_session(db, self.headers.get('Cookie',''))
        if not session:
            self.fail(401, 'Нужно войти в личный кабинет')
            return None
        if mutation:
            origin = self.headers.get('Origin')
            if origin:
                target = urlparse(origin)
                if target.netloc != self.headers.get('Host') or target.scheme not in ('http', 'https'):
                    self.fail(403, 'Недопустимый источник запроса')
                    return None
            if not hmac.compare_digest(session['csrf'], self.headers.get('X-CSRF-Token','')):
                self.fail(403, 'Проверка безопасности не пройдена. Обновите страницу')
                return None
        return session

    def do_GET(self):
        path = urlparse(self.path).path
        try:
            if path == '/api/session':
                with db_connect() as db:
                    session = get_session(db, self.headers.get('Cookie',''))
                    required = db.execute('SELECT COUNT(*) FROM users').fetchone()[0] == 0
                return self.respond(200, {'authenticated': bool(session), 'setup_required': required,
                                          'setup_allowed': is_local(self.client_address[0]), 'csrf': session['csrf'] if session else None})
            if path == '/api/public':
                with db_connect() as db:
                    d = {'profile': profile_dict(db), 'projects': table_dicts(db, 'SELECT * FROM projects ORDER BY id DESC')}
                return self.respond(200,d)
            if path.startswith('/media/'):
                key = path[7:]
                if not re.fullmatch(r'[0-9a-f]{32}\.(jpg|png|webp|gif)', key): return self.fail(404,'Не найдено')
                with db_connect() as db:
                    if profile_dict(db)['avatar_file'] != key: return self.fail(404,'Не найдено')
                return self.send_file(MEDIA/key, mimetypes.guess_type(key)[0] or 'application/octet-stream', inline=True)
            if path.startswith('/api/admin/'):
                with db_connect() as db:
                    if not self.current_session(db): return
                    if path == '/api/admin/state':
                        d = {
                          'profile': profile_dict(db),
                          'projects': table_dicts(db, 'SELECT * FROM projects ORDER BY id DESC'),
                          'tasks': table_dicts(db, 'SELECT * FROM tasks ORDER BY CASE status WHEN "todo" THEN 0 WHEN "progress" THEN 1 ELSE 2 END, id DESC'),
                          'notes': table_dicts(db, 'SELECT * FROM notes ORDER BY updated_at DESC, id DESC'),
                          'files': table_dicts(db, 'SELECT * FROM files ORDER BY id DESC'),
                          'messages': table_dicts(db, 'SELECT * FROM messages ORDER BY id DESC')
                        }
                        return self.respond(200,d)
                    if path == '/api/admin/backup': return self.send_backup(db)
                    m = re.fullmatch(r'/api/admin/files/(\d+)/download',path)
                    if m:
                        file = db.execute('SELECT * FROM files WHERE id=?',(int(m.group(1)),)).fetchone()
                        if file is None: return self.fail(404,'Файл не найден')
                        safe_filename = file['filename'].replace('"','').replace('\\','_').replace('/','_')
                        from urllib.parse import quote
                        dispo = "attachment; filename=\"download\"; filename*=UTF-8''" + quote(safe_filename)
                        return self.send_file(UPLOADS/file['stored'], 'application/octet-stream', extra={'Content-Disposition':dispo}, inline=False)
                return self.fail(404,'Адрес не найден')
            if path in ('/', '/admin'):
                return self.send_file(STATIC/'index.html','text/html; charset=utf-8')
            if path in ('/site.css','/site.js'):
                return self.send_file(STATIC/path.lstrip('/'), 'text/css; charset=utf-8' if path.endswith('.css') else 'application/javascript; charset=utf-8')
            return self.fail(404,'Страница не найдена')
        except (BrokenPipeError, ConnectionResetError): pass
        except Exception as e:
            print('GET ERROR:',repr(e),flush=True)
            try: self.fail(500,'Внутренняя ошибка сервера')
            except OSError: pass

    def send_file(self, p, mime, extra=None, inline=False):
        if not p.is_file(): return self.fail(404,'Файл не найден')
        self.send_response(200)
        self.headers_base(content_type=mime, length=p.stat().st_size, extra=extra)
        if not inline: self.send_header('Cache-Control','no-store')
        self.end_headers()
        with p.open('rb') as src:
            while block := src.read(65536): self.wfile.write(block)

    def send_backup(self, db):
        payload = {}
        for tbl in ('profile','projects','tasks','notes','files','messages'):
            payload[tbl] = table_dicts(db, f'SELECT * FROM {tbl}')
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('data.json', json.dumps(payload, ensure_ascii=False,indent=2))
            for f in payload['files']:
                p = UPLOADS/f['stored']
                if p.is_file(): z.write(p,'files/'+f['stored'])
            avatar=payload['profile'][0]['avatar_file']
            if avatar and (MEDIA/avatar).is_file(): z.write(MEDIA/avatar,'media/'+avatar)
            z.writestr('README.txt','Резервная копия личного сайта: data.json, файлы и изображение профиля.\nХраните архив в защищённом месте: он содержит личные данные.\n')
        raw=buf.getvalue()
        self.send_response(200)
        self.headers_base('application/zip',len(raw), {'Content-Disposition':'attachment; filename="my-site-backup.zip"'},no_store=True)
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self): self.change('POST')
    def do_PUT(self): self.change('PUT')
    def do_DELETE(self): self.change('DELETE')

    def change(self, method):
        path=urlparse(self.path).path
        try:
            if path == '/api/setup' and method == 'POST':
                if os.environ.get('SITE_REMOTE_DEPLOY') == '1': return self.fail(403,'Первичная настройка отключена в интернет-версии')
                if not is_local(self.client_address[0]): return self.fail(403,'Первую настройку нужно выполнить на компьютере, где запущен сайт')
                d=self.json_body()
                pw=clean_text(d.get('password',''),200,False)
                if len(pw)<10: return self.fail(400,'Пароль должен содержать не менее 10 символов')
                with db_connect() as db:
                    if db.execute('SELECT COUNT(*) FROM users').fetchone()[0]: return self.fail(409,'Владелец уже зарегистрирован')
                    salt,h=hash_password(pw)
                    db.execute('INSERT INTO users(id,password_salt,password_hash) VALUES(1,?,?)',(salt,h))
                return self.respond(201,{'ok':True})
            if path == '/api/login' and method == 'POST':
                if not throttle(('login',self.client_address[0]),8,600): return self.fail(429,'Слишком много попыток. Попробуйте позже')
                d=self.json_body()
                pw=clean_text(d.get('password',''),200,False)
                with db_connect() as db:
                    user=db.execute('SELECT * FROM users WHERE id=1').fetchone()
                    if not user: return self.fail(409,'Сначала настройте сайт на компьютере')
                    _,candidate=hash_password(pw,user['password_salt'])
                    if not hmac.compare_digest(candidate,user['password_hash']): return self.fail(401,'Неверный пароль')
                    token=secrets.token_hex(32)
                    csrf=secrets.token_hex(24)
                    db.execute('INSERT INTO sessions(token_hash,csrf,created_at,expires_at) VALUES(?,?,?,?)',(
                        hashlib.sha256(token.encode()).hexdigest(),csrf,int(time.time()),int(time.time())+SESSION_SECS))
                secure = '; Secure' if os.environ.get('SITE_HTTPS_COOKIE')=='1' or os.environ.get('SITE_REMOTE_DEPLOY')=='1' else ''
                return self.respond(200,{'ok':True}, {'Set-Cookie':f'session={token}; HttpOnly; Path=/; SameSite=Lax; Max-Age={SESSION_SECS}{secure}'})
            if path == '/api/contact' and method == 'POST':
                if not throttle(('contact',self.client_address[0]),5,3600): return self.fail(429,'Слишком много сообщений. Попробуйте позже')
                d=self.json_body()
                if d.get('website',''): return self.respond(200, {'ok':True})
                name=clean_text(d.get('name',''),100)
                email=clean_text(d.get('email',''),150)
                msg=clean_text(d.get('message',''),3000)
                if len(name)<2 or len(msg)<5 or '@' not in email or '\n' in email: return self.fail(400,'Заполните имя, электронную почту и сообщение')
                with db_connect() as db:
                    db.execute('INSERT INTO messages(name,email,body,is_read,created_at) VALUES(?,?,?,0,?)',(name,email,msg,now()))
                return self.respond(201,{'ok':True})
            if path.startswith('/api/admin/') or path == '/api/logout':
                with db_connect() as db:
                    session=self.current_session(db,mutation=True)
                    if not session: return
                    if path == '/api/logout' and method=='POST':
                        db.execute('DELETE FROM sessions WHERE token_hash=?',(session['token_hash'],))
                        extra={'Set-Cookie':'session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0'}
                        return self.respond(200,{'ok':True},extra)
                    if path == '/api/admin/profile' and method=='PUT':
                        d=self.json_body(); fields=['name','role','location','bio','about','email','telegram','website']
                        limits=[100,100,120,500,4000,150,150,300]
                        vals=[clean_text(d.get(k,''),l) for k,l in zip(fields,limits)]
                        if not vals[0]: return self.fail(400,'Имя не может быть пустым')
                        if vals[7]: vals[7]=public_link(vals[7])
                        db.execute('UPDATE profile SET '+','.join(k+'=?' for k in fields)+' WHERE id=1',vals)
                        return self.respond(200,{'ok':True})
                    if path=='/api/admin/password' and method=='POST':
                        d=self.json_body(); old=clean_text(d.get('current',''),200,False); new=clean_text(d.get('new',''),200,False)
                        if len(new)<10: return self.fail(400,'Новый пароль должен содержать не менее 10 символов')
                        user=db.execute('SELECT * FROM users WHERE id=1').fetchone()
                        _,candidate=hash_password(old,user['password_salt'])
                        if not hmac.compare_digest(candidate,user['password_hash']): return self.fail(403,'Неверный текущий пароль')
                        salt,hashed=hash_password(new)
                        db.execute('UPDATE users SET password_salt=?,password_hash=? WHERE id=1',(salt,hashed))
                        db.execute('DELETE FROM sessions WHERE token_hash<>?',(session['token_hash'],))
                        return self.respond(200,{'ok':True})
                    if path=='/api/admin/media/avatar' and method=='POST':
                        raw=self.read_bytes(IMAGE_LIMIT)
                        sig = ('png' if raw.startswith(b'\x89PNG\r\n\x1a\n') else
                               'jpg' if raw.startswith(b'\xff\xd8\xff') else
                               'gif' if raw.startswith((b'GIF87a',b'GIF89a')) else
                               'webp' if len(raw)>12 and raw[:4]==b'RIFF' and raw[8:12]==b'WEBP' else None)
                        if not sig: return self.fail(400,'Поддерживаются PNG, JPEG, WEBP и GIF')
                        key=secrets.token_hex(16)+'.'+sig
                        (MEDIA/key).write_bytes(raw)
                        old=profile_dict(db)['avatar_file']
                        db.execute('UPDATE profile SET avatar_file=? WHERE id=1',(key,))
                        if old: (MEDIA/old).unlink(missing_ok=True)
                        return self.respond(201,{'ok':True})
                    if path=='/api/admin/files' and method=='POST':
                        name=unquote(self.headers.get('X-File-Name',''))
                        name=Path(name.replace('\\','/')).name
                        name=''.join(c for c in name if ord(c)>=32 and c not in '\x7f')
                        name=clean_text(name,180)
                        if not name: return self.fail(400,'Имя файла отсутствует')
                        raw=self.read_bytes(FILE_LIMIT)
                        key=secrets.token_hex(20)
                        (UPLOADS/key).write_bytes(raw)
                        mime=mimetypes.guess_type(name)[0] or 'application/octet-stream'
                        db.execute('INSERT INTO files(filename,stored,size,mime,uploaded_at) VALUES(?,?,?,?,?)',(name,key,len(raw),mime,now()))
                        return self.respond(201,{'ok':True})
                    # Projects
                    if path=='/api/admin/projects' and method=='POST':
                        d=self.json_body()
                        title=clean_text(d.get('title',''),120)
                        if not title: return self.fail(400,'Укажите название проекта')
                        vals=(title,clean_text(d.get('category',''),60),clean_text(d.get('description',''),1200),public_link(d.get('url','')),now())
                        db.execute('INSERT INTO projects(title,category,description,url,created_at) VALUES(?,?,?,?,?)',vals)
                        return self.respond(201,{'ok':True})
                    m=re.fullmatch(r'/api/admin/projects/(\d+)',path)
                    if m and method in ('PUT','DELETE'):
                        i=int(m.group(1))
                        if method=='DELETE': db.execute('DELETE FROM projects WHERE id=?',(i,)); return self.respond(200,{'ok':True})
                        d=self.json_body(); title=clean_text(d.get('title',''),120)
                        if not title: return self.fail(400,'Укажите название проекта')
                        vals=(title,clean_text(d.get('category',''),60),clean_text(d.get('description',''),1200),public_link(d.get('url','')),i)
                        db.execute('UPDATE projects SET title=?,category=?,description=?,url=? WHERE id=?',vals)
                        return self.respond(200,{'ok':True})
                    # Tasks
                    if path=='/api/admin/tasks' and method=='POST':
                        d=self.json_body(); title=clean_text(d.get('title',''),200)
                        if not title: return self.fail(400,'Введите задачу')
                        due=clean_text(d.get('due_date',''),10)
                        if due and not re.fullmatch(r'\d{4}-\d{2}-\d{2}',due): return self.fail(400,'Некорректная дата')
                        db.execute('INSERT INTO tasks(title,status,due_date,created_at) VALUES(?,?,?,?)',(title,'todo',due,now()))
                        return self.respond(201,{'ok':True})
                    m=re.fullmatch(r'/api/admin/tasks/(\d+)',path)
                    if m and method in ('PUT','DELETE'):
                        i=int(m.group(1))
                        if method=='DELETE': db.execute('DELETE FROM tasks WHERE id=?',(i,)); return self.respond(200,{'ok':True})
                        d=self.json_body(); status=clean_text(d.get('status',''),20)
                        if status not in ('todo','progress','done'): return self.fail(400,'Недопустимый статус')
                        db.execute('UPDATE tasks SET status=? WHERE id=?',(status,i)); return self.respond(200,{'ok':True})
                    # Notes
                    if path=='/api/admin/notes' and method=='POST':
                        d=self.json_body(); title=clean_text(d.get('title',''),150); body=clean_text(d.get('body',''),20000,False)
                        if not title: return self.fail(400,'Укажите заголовок заметки')
                        db.execute('INSERT INTO notes(title,body,updated_at) VALUES(?,?,?)',(title,body,now()))
                        return self.respond(201,{'ok':True})
                    m=re.fullmatch(r'/api/admin/notes/(\d+)',path)
                    if m and method in ('PUT','DELETE'):
                        i=int(m.group(1))
                        if method=='DELETE': db.execute('DELETE FROM notes WHERE id=?',(i,)); return self.respond(200,{'ok':True})
                        d=self.json_body(); title=clean_text(d.get('title',''),150)
                        if not title: return self.fail(400,'Укажите заголовок заметки')
                        db.execute('UPDATE notes SET title=?,body=?,updated_at=? WHERE id=?',(title,clean_text(d.get('body',''),20000,False),now(),i))
                        return self.respond(200,{'ok':True})
                    # Files
                    m=re.fullmatch(r'/api/admin/files/(\d+)',path)
                    if m and method=='DELETE':
                        i=int(m.group(1)); file=db.execute('SELECT stored FROM files WHERE id=?',(i,)).fetchone()
                        if file:
                            db.execute('DELETE FROM files WHERE id=?',(i,))
                            (UPLOADS/file['stored']).unlink(missing_ok=True)
                        return self.respond(200,{'ok':True})
                    # Messages
                    m=re.fullmatch(r'/api/admin/messages/(\d+)',path)
                    if m and method in ('PUT','DELETE'):
                        i=int(m.group(1))
                        if method=='DELETE': db.execute('DELETE FROM messages WHERE id=?',(i,)); return self.respond(200,{'ok':True})
                        d=self.json_body(); read=1 if d.get('is_read') else 0
                        db.execute('UPDATE messages SET is_read=? WHERE id=?',(read,i)); return self.respond(200,{'ok':True})
                return self.fail(404,'Адрес не найден')
            return self.fail(404,'Адрес не найден')
        except ValueError as e: return self.fail(400,str(e))
        except (BrokenPipeError, ConnectionResetError): pass
        except Exception as e:
            print('MUTATION ERROR:',repr(e),flush=True)
            try: self.fail(500,'Внутренняя ошибка сервера')
            except OSError: pass


def main():
    p=argparse.ArgumentParser(description='Личный сайт и личный кабинет')
    p.add_argument('--host',default='127.0.0.1',help='127.0.0.1 (только компьютер) или 0.0.0.0 (локальная сеть)')
    p.add_argument('--port',type=int,default=int(os.environ.get('PORT', '8000')))
    args=p.parse_args()
    initialize()
    s=ThreadingHTTPServer((args.host,args.port),App)
    print(f'Yuriy Project запущен, порт {args.port}',flush=True)
    if args.host=='0.0.0.0': print('ВНИМАНИЕ: сайт доступен по локальной сети. Не публикуйте без HTTPS и защиты сервера.',flush=True)
    print('Для остановки нажмите Ctrl+C',flush=True)
    try: s.serve_forever()
    except KeyboardInterrupt: pass
    finally: s.server_close()

if __name__=='__main__': main()
