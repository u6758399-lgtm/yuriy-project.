@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ========================================
echo   МОЕ ПРОСТРАНСТВО - ЛИЧНЫЙ САЙТ
echo ========================================
echo.
echo Откройте в браузере:
echo http://127.0.0.1:8000/admin
echo.
echo Для остановки нажмите Ctrl+C
echo.
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 app.py
) else (
    python app.py
)
if errorlevel 1 (
    echo.
    echo Ошибка запуска. Убедитесь, что установлен Python 3.10 или новее.
    pause
)
