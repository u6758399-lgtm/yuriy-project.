@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================
echo  МОЕ ПРОСТРАНСТВО - ДОСТУП С ТЕЛЕФОНА
 echo ==============================================
echo.
echo ВАЖНО: сначала создайте пароль владельца
 echo через start_windows.bat на этом компьютере.
echo Разрешайте доступ только в своей частной сети.
echo Не настраивайте проброс порта на роутере.
echo.
echo Адрес компьютера (IPv4):
ipconfig | findstr /i "IPv4"
echo.
echo На телефоне откройте: http://IP_КОМПЬЮТЕРА:8000
 echo Телефон и компьютер должны быть в одной сети Wi-Fi.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 app.py --host 0.0.0.0
) else (
    python app.py --host 0.0.0.0
)
if errorlevel 1 (
    echo Ошибка запуска: проверьте Python и занятость порта 8000.
    pause
)
